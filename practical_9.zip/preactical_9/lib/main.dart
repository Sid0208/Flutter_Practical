import 'package:flutter/material.dart';

void main() {
  runApp(MyApppp());
}

class MyApppp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text("Practical-9"),
        ),
        body: GridView.count(
            crossAxisCount: 2,
            crossAxisSpacing: 8.0,
            mainAxisSpacing: 8.0,
            childAspectRatio: 1.5,
            padding: EdgeInsets.all(8.0),
            children: List.generate(8, (index) {
              return Container(
                margin: EdgeInsets.all(8.0),
                color: Colors.amber[100 * (index % 9)],
                child: Center(
                  child: Text(
                    'Item $index',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              );
            })),
      ),
    );
  }
}
